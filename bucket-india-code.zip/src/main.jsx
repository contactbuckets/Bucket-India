import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import ProtectedRoute from "./components/auth/ProtectedRoute";
import Login from "./pages/Login";
import Seller from "./pages/Seller";
import Vendor from "./pages/Vendor";
import "./style.css";

function App() {
  return <Routes>
    <Route path="/login" element={<Login />} />
    <Route path="/seller" element={<ProtectedRoute role="seller"><Seller /></ProtectedRoute>} />
    <Route path="/vendor" element={<ProtectedRoute role="vendor"><Vendor /></ProtectedRoute>} />
    <Route path="*" element={<Navigate to="/login" replace />} />
  </Routes>;
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode><BrowserRouter><AuthProvider><App /></AuthProvider></BrowserRouter></React.StrictMode>
);