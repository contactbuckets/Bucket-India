import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import { useAuth } from "../context/AuthContext";

export default function Vendor(){
  const {session,signOut}=useAuth();
  const [products,setProducts]=useState([]),[orders,setOrders]=useState([]),[title,setTitle]=useState(""),[price,setPrice]=useState(""),[desc,setDesc]=useState(""),[msg,setMsg]=useState("");

  async function load(){
    const [{data:p},{data:o}]=await Promise.all([
      supabase.from("products").select("*").eq("vendor_id",session.user.id).order("created_at",{ascending:false}),
      supabase.from("orders").select("*").eq("vendor_id",session.user.id).order("created_at",{ascending:false})
    ]);
    setProducts(p||[]);setOrders(o||[]);
  }
  useEffect(()=>{load()},[session.user.id]);

  async function add(e){
    e.preventDefault();setMsg("");
    const {error}=await supabase.from("products").insert({vendor_id:session.user.id,title,description:desc,cost_price:Number(price),status:"active"});
    setMsg(error?error.message:"Product published."); if(!error){setTitle("");setPrice("");setDesc("");load();}
  }
  async function status(id,value){
    const {error}=await supabase.from("orders").update({status:value}).eq("id",id);
    setMsg(error?error.message:"Order updated.");if(!error)load();
  }

  return <div className="app"><header><div className="brand">Vendor Dashboard</div><button onClick={signOut}>Sign out</button></header><section className="content">
    <div className="split">
      <form className="card form" onSubmit={add}><h2>Publish product</h2><input placeholder="Product title" value={title} onChange={e=>setTitle(e.target.value)} required/><input type="number" placeholder="Cost price" value={price} onChange={e=>setPrice(e.target.value)} required/><textarea placeholder="Description" value={desc} onChange={e=>setDesc(e.target.value)}/><button className="primary">Publish</button></form>
      <div className="card"><h2>Your products</h2>{products.map(p=><div className="list-row" key={p.id}><span>{p.title}</span><b>₹{p.cost_price}</b></div>)}{!products.length&&<p className="muted">No products yet.</p>}</div>
    </div>
    {msg&&<div className="notice">{msg}</div>}
    <div className="card"><h2>Orders</h2>{orders.map(o=><div className="list-row" key={o.id}><span>Order {o.id.slice(0,8)} · ₹{o.total_amount??0}</span><select value={o.status||"pending"} onChange={e=>status(o.id,e.target.value)}><option>pending</option><option>confirmed</option><option>shipped</option><option>delivered</option><option>cancelled</option></select></div>)}{!orders.length&&<p className="muted">No orders yet.</p>}</div>
  </section></div>;
}