import { useEffect, useMemo, useState } from "react";
import { supabase } from "../lib/supabase";
import { useAuth } from "../context/AuthContext";

export default function Seller() {
  const { session, signOut } = useAuth();
  const [products,setProducts]=useState([]), [stores,setStores]=useState([]), [listings,setListings]=useState([]);
  const [search,setSearch]=useState(""), [margin,setMargin]=useState(100), [storeId,setStoreId]=useState("");
  const [loading,setLoading]=useState(true), [msg,setMsg]=useState("");

  async function load() {
    setLoading(true);
    const [{data:p},{data:s},{data:l}] = await Promise.all([
      supabase.from("products").select("*").eq("status","active").order("created_at",{ascending:false}),
      supabase.from("stores").select("*").eq("seller_id",session.user.id),
      supabase.from("listings").select("*").eq("seller_id",session.user.id)
    ]);
    setProducts(p||[]); setStores(s||[]); setListings(l||[]);
    if (s?.[0] && !storeId) setStoreId(s[0].id);
    setLoading(false);
  }
  useEffect(()=>{load()},[session.user.id]);

  const filtered=useMemo(()=>products.filter(p=>(p.title||"").toLowerCase().includes(search.toLowerCase())),[products,search]);

  async function push(p) {
    if(!storeId) return setMsg("Add/select a Shopify store first.");
    const price=Number(p.cost_price||0)+Number(margin||0);
    const {error}=await supabase.from("listings").upsert({
      product_id:p.id,seller_id:session.user.id,store_id:storeId,margin_amount:Number(margin||0),selling_price:price,status:"active"
    },{onConflict:"product_id,seller_id,store_id"});
    setMsg(error ? error.message : `${p.title} added to your store catalog.`);
    if(!error) load();
  }

  return <Dashboard title="Seller Dashboard" signOut={signOut}>
    <div className="toolbar"><input placeholder="Search products…" value={search} onChange={e=>setSearch(e.target.value)}/>
      <select value={storeId} onChange={e=>setStoreId(e.target.value)}><option value="">Select store</option>{stores.map(s=><option key={s.id} value={s.id}>{s.shop_domain}</option>)}</select>
      <input className="small" type="number" value={margin} onChange={e=>setMargin(e.target.value)} placeholder="Margin"/></div>
    {msg&&<div className="notice">{msg}</div>}
    {loading?<div className="center">Loading products…</div>:<div className="grid">{filtered.map(p=><div className="product card" key={p.id}>
      <div className="product-image">{p.image_url?<img src={p.image_url} alt=""/>:<span>No image</span>}</div>
      <h3>{p.title}</h3><p className="muted">{p.description||"Vendor product"}</p>
      <div className="row"><b>Cost ₹{p.cost_price??0}</b><b>Sell ₹{Number(p.cost_price||0)+Number(margin||0)}</b></div>
      <button className="primary" onClick={()=>push(p)}>Add to Shopify</button>
    </div>)}</div>}
  </Dashboard>;
}

function Dashboard({title,signOut,children}){return <div className="app"><header><div className="brand">{title}</div><button onClick={signOut}>Sign out</button></header><section className="content">{children}</section></div>}