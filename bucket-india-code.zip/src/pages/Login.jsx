import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabase";

export default function Login() {
  const nav = useNavigate();
  const [mode, setMode] = useState("login");
  const [role, setRole] = useState("seller");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault(); setError(""); setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { data: { full_name: name, requested_role: role } }
        });
        if (error) throw error;
        setMode("login");
        setError("Account created. If email confirmation is enabled, confirm your email before signing in.");
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        const { data: p } = await supabase.from("profiles").select("role").eq("id", data.user.id).single();
        nav(p?.role === "vendor" ? "/vendor" : "/seller");
      }
    } catch (e) { setError(e.message || "Something went wrong"); }
    finally { setBusy(false); }
  }

  return <main className="auth">
    <form className="card auth-card" onSubmit={submit}>
      <div className="brand">Bucket India</div>
      <h1>{mode === "login" ? "Welcome back" : "Create account"}</h1>
      <p className="muted">Dropshipping marketplace for sellers and vendors.</p>
      {mode === "signup" && <input placeholder="Full name" value={name} onChange={e=>setName(e.target.value)} required />}
      <input type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required />
      <input type="password" placeholder="Password" minLength="6" value={password} onChange={e=>setPassword(e.target.value)} required />
      {mode === "signup" && <div className="role-switch">
        <button type="button" className={role==="seller"?"active":""} onClick={()=>setRole("seller")}>Seller</button>
        <button type="button" className={role==="vendor"?"active":""} onClick={()=>setRole("vendor")}>Vendor</button>
      </div>}
      {error && <div className="notice">{error}</div>}
      <button className="primary" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}</button>
      <button type="button" className="link" onClick={()=>{setMode(mode==="login"?"signup":"login");setError("")}}>
        {mode === "login" ? "Create a new account" : "Already have an account? Sign in"}
      </button>
    </form>
  </main>;
}